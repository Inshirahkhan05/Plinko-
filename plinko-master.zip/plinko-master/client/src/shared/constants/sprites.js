// wood textured circle
// export const CHIP_SPRITE = 'https://i.imgur.com/z5CFGms.png';
// blue tone circle
// export const CHIP_SPRITE = 'https://i.imgur.com/Q6GxA85.png';
// poker chip
export const CHIP_SPRITE = 'https://i.imgur.com/9Y4xcps.png';
// grey and white wheel (inside transparency needs to be made white)
// export const CHIP_SPRITE = 'https://i.imgur.com/r3vbOI4.png';

// white triangle
export const TRIANGLE_RIGHT_SPRITE = 'https://i.imgur.com/vjI9mpy.png';
export const TRIANGLE_LEFT_SPRITE = 'https://i.imgur.com/pfLBiwT.png';

// white circle
export const PEG_SPRITE = 'https://i.imgur.com/ND1YGoj.png';
